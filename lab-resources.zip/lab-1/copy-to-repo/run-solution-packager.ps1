.\tools\CoreTools\SolutionPackager.exe `
    /action Extract `
    /zipfile .\contoso_university_core.zip `
    /folder .\contents `
    /packagetype Both